// #include <iostream>
// #include <cstdlib>
// #include <unistd.h>
// #include <string>
// #include <fstream>
// #include "UniversalSorter.hpp"

// int main(int argc, char*argv[])
// {

//     double threshold_cost = 0, comparison_coefficient = 0, movimentation_coefficient = 0, call_coefficient = 0;
//     int seed = 0, num_of_keys = 0;
//     std::string file_name, line;
    
//     if (argc != 2) {
//         std::cerr << "Erro: file name needed" << std::endl;
//         return 1;
//     }

//    file_name = argv[1];

//     std::ifstream file(file_name);
    
//     if (!file) {
//         std::cerr << "Erro ao abrir o arquivo.\n";
//         return 1;
//     }
    
//     file >> seed;
//     file >> threshold_cost;
//     file >> comparison_coefficient;
//     file >> movimentation_coefficient;
//     file >> call_coefficient;
//     file >> num_of_keys;
    
//     srand48(seed);
    
//     UniversalSorter universal_sorter(comparison_coefficient, movimentation_coefficient, call_coefficient);
//     int *vet = new int[num_of_keys]; 

//     for(int i=0;i<num_of_keys;i++){
//         file >> vet[i];
//     }

//     std::cout<<"size "<<num_of_keys<<" seed "<<seed<<" breaks "<<universal_sorter.count_breaks(vet, num_of_keys)<<std::endl;
    
//     //calculating partition and break threshold
//     int partition_threshold = universal_sorter.determine_partition_threshold(vet, num_of_keys, threshold_cost);
//     universal_sorter.determine_break_threshold(partition_threshold, vet, num_of_keys, threshold_cost, seed);

//     delete(vet);
//     file.close();

//     return 0;
// }
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <cstring>
#include "UniversalSorter.hpp"



int main(){
    int i, j ,p;
    long mult = (long) pow(10,KEYSIZE-1);
    srand48(1);
    item vet[VETSIZE];
    UniversalSorter universal_sorter(0.0121560, -0.0063780, 0.0172897);

    for(i=0;i<VETSIZE;i++){
        for(j = (int)(drand48() * mult), p = KEYSIZE-2;p>=0;j /=10,p--){
            vet[i].key[p] = '0'+ j % 10;
        }
        vet[i].key[KEYSIZE - 1]=0;
        for(j=0;j<REGISTERSIZE-1;j++){
            vet[i].payload[j] = '0' +j % 10;
        }
        vet[i].payload[REGISTERSIZE - 1] = 0;
    }

    for(i=0;i<VETSIZE;i++){
        std::cout<<i<<" key "<<vet[i].key<<" register" <<vet[i].payload<<std::endl;
    }
    universal_sorter.determine_partition_threshold(vet, VETSIZE, 10.000000);
}