#include "UniversalSorter.hpp"
#include <unistd.h>
#include <cmath>
#include <iomanip>

UniversalSorter::UniversalSorter(double comp_coefficient,
                                 double mov_coefficient, double call_coefficient) : comparison_coefficient(comp_coefficient),
                                                                                  movimentation_coefficient(mov_coefficient), call_coefficient(call_coefficient) {}


//Function that counts how many times an item at the vector is bigger than its successor 
int UniversalSorter::count_breaks(item *vet, int size)
{
  int result = 0;
  for (int i = 1; i < size; i++)
  {
    if (vet[i - 1] > vet[i])
    {
      result++;
    }
  }
  return result;
}

//Function that decides which sorting algorithm is appropriate based on partition and breaks threshold,pior caso 
void UniversalSorter::universal_sorter(item *v, int v_size, int partition_threshold, int breaks_threshold)
{
  int num_breaks = this->count_breaks(v, v_size);

  if (num_breaks < breaks_threshold)
  {
    this->sorter.insertionSort(v, 0, v_size - 1, &operation_counter);
  }
  else
  {
    if (v_size > partition_threshold)
    {
      this->sorter.quickSort3Ins(v, 0, v_size - 1, partition_threshold,  &operation_counter);
    }
    else
    {
      this->sorter.insertionSort(v, 0, v_size - 1, &operation_counter);
    }
  }
}

//Calculates cost based on number of comparisons, movimentatios, calls and its coefficients 
double UniversalSorter::calculate_cost()
{
  double cost = this->comparison_coefficient * this->operation_counter.get_cmp() + this->movimentation_coefficient * this->operation_counter.get_move() + this->call_coefficient * this->operation_counter.get_calls();
  return cost;
}

//Print statics of each partition size tested 
void UniversalSorter::print_partition_statics(PartitionStatistics *partition_statistics)
{
  std::cout << "mps " << partition_statistics->partition_size << " cost " << std::fixed << std::setprecision(9) << partition_statistics->cost << " cmp " << partition_statistics->num_of_comparisons << " move " << partition_statistics->num_of_movements << " calls " << partition_statistics->num_of_calls << std::endl;
}

// Register the cost, number of comparisons, calls and movements of each partition size tested 
void UniversalSorter::register_partition_statistics(PartitionStatistics *statistics, int num_partitions, int partition_size)
{
  statistics[num_partitions].cost = this->calculate_cost();
  statistics[num_partitions].num_of_calls = this->operation_counter.get_calls();
  statistics[num_partitions].num_of_comparisons = this->operation_counter.get_cmp();
  statistics[num_partitions].num_of_movements = this->operation_counter.get_move();
  statistics[num_partitions].partition_size = partition_size;
}

//Print the number of partitions sizes tested and the partition whose cost was the best
void UniversalSorter::print_final_results(int num_partitions, int best_partition, double difference_max_min_cost)
{

  std::cout << "nummps " << num_partitions << " limParticao " << best_partition << " mpsdiff " << std::fixed << std::setprecision(6) << difference_max_min_cost << std::endl;
}

//Find the minimun cost of the partition sizes tested 
int UniversalSorter::find_min_cost(PartitionStatistics *statistics, int num_partitions)
{
  int min_cost_index = 0;
  for (int i = 1; i < num_partitions; i++)
  {
    if (statistics[min_cost_index].cost > statistics[i].cost)
    {
      min_cost_index = i;
    }
  }
  return min_cost_index;
}
//Find the partition size using the correspondent index 
int UniversalSorter::find_partition_size(int index, int min_partition_size, int step)
{
  return min_partition_size + index * step;
}

//Function that find the partion size/number of breaks from index 
int UniversalSorter::find_index_by_partition(int partition_size, int min_partition_size, int step)
{
  return (partition_size - min_partition_size) / step;
}

//Function that finds new range of values to test minimum partitions sizes / minimum number of breaks
void UniversalSorter::find_new_range(int min_cost_index, int *min_size_range, int *max_size_range, int num_sizes, int *step)
{
  int new_min_index = 0, new_max_index = 0;
  //if value was the first one tested, new range will go from the first tested to the third
  if (min_cost_index == 0)
  {
    new_min_index = 0;
    new_max_index = 2;
  }
  //if value was the last tested, we use it and the third last as new range
  else if (min_cost_index == num_sizes - 1)
  {
    new_min_index = num_sizes - 3;
    new_max_index = num_sizes - 1;
  }
  else
  //if value wan't the last or first, we use the values tested before and after as new range 
  {
    new_min_index = min_cost_index - 1;
    new_max_index = min_cost_index + 1;
  }
  
  *max_size_range = this->find_partition_size(new_max_index, *min_size_range, *step);
  *min_size_range = this->find_partition_size(new_min_index, *min_size_range, *step);

  //update step based on new max and min values of the range
  *step = (int)((*max_size_range - *min_size_range) / 5);

  if (*step == 0)
  {
    *step = 1;
  }
}

//Function to determine the partition size where the cost of insertion sort is lower than that of quicksort
int UniversalSorter::determine_partition_threshold(item *v, int v_size, double cost_threshold)
{
  int min_partition_size_range = 2, max_partition_size_range = v_size,
  step = (int)((max_partition_size_range - min_partition_size_range) / 5), 
  best_partition = 0, 
  min_cost_index = 0, 
  current_index = 0;
  int num_partitions = this->find_index_by_partition(max_partition_size_range, min_partition_size_range, step) + 1;
  int iter = 0, i = 0;
  item *v_copy = new item[v_size];
  
  float difference_max_min_cost = cost_threshold + 1;
  PartitionStatistics *statistics;


  while (difference_max_min_cost > cost_threshold && num_partitions >= 5)
  {
    //discovers how many partitions sizes will be tested
    num_partitions = this->find_index_by_partition(max_partition_size_range, min_partition_size_range, step) + 1;
    current_index = 0;
    statistics = new PartitionStatistics[num_partitions];
    
    std::cout<<std::endl;
    std::cout << "iter " << iter << std::endl;
    
    for (i = min_partition_size_range; i <= max_partition_size_range; i += step)
    {
       //copy the original vector to a temporary vector to facilitate resetting for each partition size test
      for (int j = 0; j < v_size; j++)
      {
        v_copy[j] = v[j];
      }

      this->universal_sorter(v_copy, v_size, i, 0);

      for(int t=0;t<v_size;t++){
        std::cout<<v_copy[t].key<<std::endl;
      }

      this->register_partition_statistics(statistics, current_index, i);
      this->print_partition_statics(&statistics[current_index]);

      current_index++;
      this->operation_counter.resetcounter();
    }
    //find the tested partition with the lowest cost 
    min_cost_index = this->find_min_cost(statistics, num_partitions);
    best_partition = this->find_partition_size(min_cost_index, min_partition_size_range, step);

    int last_min_partition_size_range = min_partition_size_range;
    int last_step = step;
    this->find_new_range(min_cost_index, &min_partition_size_range, &max_partition_size_range, num_partitions, &step);

    difference_max_min_cost = 
    fabs(statistics[this->find_index_by_partition(max_partition_size_range, last_min_partition_size_range,last_step)].cost -
    statistics[this->find_index_by_partition(min_partition_size_range, last_min_partition_size_range,last_step)].cost);

    this->print_final_results(num_partitions, best_partition, difference_max_min_cost);
    iter++;
    delete[] statistics;
  }
  delete[] v_copy;
  return best_partition;
}

//function that creates breaks on a sorted vector
void UniversalSorter::shuffleVector(item *vet, int vet_size, int num_breaks, int seed)
{
  int index1 = 0, index2 = 0;
  item temp;
  srand48(seed);

  for (int i = 0; i < num_breaks; i++)
  {
    while (index1 == index2)
    {
      index1 = (int)(drand48() * vet_size);
      index2 = (int)(drand48() * vet_size);
    }
      temp = vet[index1];
      vet[index1] = vet[index2];
      vet[index2] = temp;
      index1 = index2 = 0;
  }
}

//function that prints quicksort performance statistics on a vector with a defined number of breaks
void UniversalSorter::print_statics_quick(BreaksStatistics breaks_statistics)
{
  std::cout << "qs lq " << breaks_statistics.num_breaks << " cost " << std::fixed << std::setprecision(9) << breaks_statistics.cost << " cmp " << breaks_statistics.num_of_comparisons << " move " << breaks_statistics.num_of_movements << " calls " << breaks_statistics.num_of_calls << std::endl;
}
//function that prints insertion sort performance statistics on a vector with a defined number of breaks
void UniversalSorter::print_statics_insertion(BreaksStatistics breaks_statistics)
{
  std::cout << "in lq " << breaks_statistics.num_breaks << " cost " << std::fixed << std::setprecision(9) << breaks_statistics.cost << " cmp " << breaks_statistics.num_of_comparisons << " move " << breaks_statistics.num_of_movements << " calls " << breaks_statistics.num_of_calls << std::endl;
}
//function that registers quicksort/insertion sort performances statistics on a vector with a defined number of breaks
void UniversalSorter::register_break_statistics(BreaksStatistics *statistics_quick_sort, int num_breaks)
{
  statistics_quick_sort->cost = this->calculate_cost();
  statistics_quick_sort->num_of_calls = this->operation_counter.get_calls();
  statistics_quick_sort->num_of_comparisons = this->operation_counter.get_cmp();
  statistics_quick_sort->num_of_movements = this->operation_counter.get_move();
  statistics_quick_sort->num_breaks = num_breaks;
}
//finds the number of breaks where the cost of insertion sort and quicksort is most similar
int UniversalSorter::find_num_breaks_with_min_cost_difference(BreaksStatistics *statistics_quick_sort, BreaksStatistics *statistics_insertion_sort, int num_breaks)
{
  int min_cost_index = 0;
  double difference = 0;
  double best_difference = fabs(statistics_quick_sort[0].cost - statistics_insertion_sort[0].cost);

  for (int i = 1; i < num_breaks; i++)
  {
    difference = fabs(statistics_quick_sort[i].cost - statistics_insertion_sort[i].cost);
    if (best_difference > difference)
    {
      min_cost_index = i;
      best_difference = difference;
    }
    
  }
  return min_cost_index;
}
//prints the final result with the numer of breaks whose cost is similiar to quicksort cost
void UniversalSorter::print_break_thershold_result(int partition_size, double difference_max_min_size, int num_size_breaks)
{
  std::cout << "numlq " << num_size_breaks << " limQuebras " << partition_size << " lqdiff " << std::fixed << std::setprecision(6) << difference_max_min_size << std::endl;
  
}

//determine the number of breaks at the for which is better to use insertion sort than quicksort
void UniversalSorter::determine_break_threshold(int partition_threshold, item *vet, int vet_size, double cost_threshold, int seed)
{
  int min_num_breaks_range = 1, max_num_breaks_range = vet_size / 2,
  step = (int)(max_num_breaks_range - min_num_breaks_range) / 5, 
  num_breaks = 5, iter = 0, i = 0, min_cost_index = 0, current_index = 0;

  float difference_max_min_cost = cost_threshold + 1;

  BreaksStatistics *statistics_quick_sort, *statistics_insertion_sort;

  this->universal_sorter(vet, vet_size, partition_threshold, 0);
  this->operation_counter.resetcounter();


  while (difference_max_min_cost > cost_threshold && num_breaks >= 5)
  {
    num_breaks = this->find_index_by_partition(max_num_breaks_range, min_num_breaks_range, step) + 1;

    std::cout<<std::endl;
    current_index = 0;
    std::cout << "iter "<<iter << std::endl;

    statistics_insertion_sort = new BreaksStatistics[num_breaks];
    statistics_quick_sort = new BreaksStatistics[num_breaks];

    for (i = min_num_breaks_range; i <= max_num_breaks_range; i += step)
    {
      //use sorted vet and create breaks to test it with quicksort
      this->shuffleVector(vet, vet_size, i, seed);
      this->sorter.quickSort3Ins(vet, 0, vet_size - 1, partition_threshold, &this->operation_counter);
      this->register_break_statistics(&statistics_quick_sort[current_index], i);
      this->print_statics_quick(statistics_quick_sort[current_index]);
      this->operation_counter.resetcounter();
      
       //use sorted and create breaks to test it with insertionsort
      this->shuffleVector(vet, vet_size, i, seed);
      this->sorter.insertionSort(vet, 0, vet_size - 1, &this->operation_counter);
      this->register_break_statistics(&statistics_insertion_sort[current_index], i);
      this->print_statics_insertion(statistics_insertion_sort[current_index]);
      this->operation_counter.resetcounter();
      current_index++;
    }
    //finds best number of breaks tested
    min_cost_index = this->find_num_breaks_with_min_cost_difference(statistics_quick_sort, statistics_insertion_sort, num_breaks);
    int last_min_num_breaks_range = min_num_breaks_range;
    int last_step = step;
    this->find_new_range(min_cost_index, &min_num_breaks_range, &max_num_breaks_range, num_breaks, &step);
    
    difference_max_min_cost = fabs(statistics_insertion_sort[this->find_index_by_partition(max_num_breaks_range, last_min_num_breaks_range,
    last_step)].cost -statistics_insertion_sort[this->find_index_by_partition(min_num_breaks_range, last_min_num_breaks_range,
    last_step)].cost);

    this->print_break_thershold_result(this->find_partition_size(min_cost_index, last_min_num_breaks_range, last_step), difference_max_min_cost, num_breaks);
    delete[] statistics_insertion_sort;
    delete[] statistics_quick_sort;
    iter++;
  }
}